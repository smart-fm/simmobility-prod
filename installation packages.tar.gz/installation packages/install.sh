sudo apt-get -y install libboost1.54-all-dev
sudo apt-get -y install -f
sudo apt-get -y install libcppunit-dev
sudo apt-get -y install -f
sudo apt-get -y install libjsoncpp-dev
sudo apt-get -y install -f
sudo apt-get -y install liblua5.2-dev
sudo apt-get -y install -f
sudo apt-get -y install libpq-dev
sudo apt-get -y install -f
sudo apt-get -y install libtinyxml-dev
sudo apt-get -y install -f
sudo apt-get -y install libxerces-c-dev
sudo apt-get -y install -f
sudo apt-get -y install mongodb
sudo apt-get -y install -f
sudo apt-get -y install xsdcxx
sudo apt-get -y install -f
sudo apt-get -y install cmake
sudo apt-get -y install -f
sudo apt-get -y install g++
sudo apt-get -y install -f
sudo apt-get -y install libpqxx-dev
sudo apt-get -y install -f
sudo dpkg -i libsoci-core-gcc_3.2.2-1_amd64.deb
sudo dpkg -i libsoci-core-gcc-dev_3.2.2-1_amd64.deb
sudo dpkg -i libsoci-postgresql-gcc_3.2.2-1_amd64.deb
sudo dpkg -i  --instdir=$HOME simmobility-amd64.deb
sudo chmod -R ugo+rw ~/simmobility/source
